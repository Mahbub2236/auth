<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Middleware\CheckUserCookieMiddleware;
use Illuminate\Support\Facades\Route;

  
// Authentication routes
Route::get('/register-page',[AuthController::class, 'registerPage']);

Route::get('/login-page',[AuthController::class, 'loginPage']);

